package com.example.startquiz

data class CategoryModel(val name: String, val image: Int)
