package com.example.startquiz

data class Model(val image: Int, val title1: String)